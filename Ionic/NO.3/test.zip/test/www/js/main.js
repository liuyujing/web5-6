/**
 * Created by liuyujing on 2017/3/27.
 */
(function () {

  angular.module("app",["ionic"]);


})();
