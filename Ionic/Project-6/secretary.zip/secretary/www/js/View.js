/**
 * Created by liuyujing on 2017/3/30.
 */
// (function () {
//
//   function View() {
//
//     document.createElement("h1").textContent = this.title;
//   }
//
//   window.View = View;
// })();
