/**
 * Created by liuyujing on 2017/4/7.
 */


//接口相关

//主机地址
HOST = "http://localhost:3000";
//注册
REGISTER = "/users/register";

