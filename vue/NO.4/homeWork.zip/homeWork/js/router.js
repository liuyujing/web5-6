/**
 * Created by liuyujing on 2017/3/15.
 */
(function () {

    // var config = {
    //     routes:[
    //         {path:"/",component:randPerson},
    //         {path:"/add",component:addPerson},
    //         {path:"/login",component:login}
    //     ]
    // };
    //
    // window.router = new VueRouter(config);

})();